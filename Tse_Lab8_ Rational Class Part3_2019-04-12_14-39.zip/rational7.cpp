#include "rational7.h"

//precondition:@param istream variable
//postcondition:sets numerator and denominator from inputs
void rational::input(istream& ins){
    int a,b;
    char slash;
    ins>>a;
    ins>>slash;
    ins>>b;
    while(b==0){
        cout<<"Error: bad rational";
        cin>>a;
        cin>>slash;
        cin>>b;
        cout<<endl;
    }
    numerator=a;
    denominator=b;
}

//precondition:@param outstream variable
//postcondition:prints numerator and denominator

//precondition:@param const int : unchangable inputs
//postcondition:sets numerator and denominator
void rational::set(const int &num, const int &dem){
    numerator=num;
    denominator=dem;
}

//postcondition:returns numerator
int rational::get_numerator(){
    int n=numerator;
    return n;
}

//postcondition returns denominator
int rational::get_denominator(){
    int d=denominator;
    return d;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns a rational temp that stores the sum
rational operator + (const rational& op1, const rational& op2){
    rational temp;
    temp.numerator=op1.numerator*op2.denominator+op1.denominator*op2.numerator;
    temp.denominator=op1.denominator*op2.denominator;
    temp.simplify();
    return temp;
}
//precondition: @param const rational&: unchangable inputs
//postcondition: returns a rational temp that stores the difference
rational operator - (const rational& op1, const rational& op2){
    rational temp;
    temp.numerator=op1.numerator*op2.denominator-op1.denominator*op2.numerator;
    temp.denominator=op1.denominator*op2.denominator;
    temp.simplify();
    return temp;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns a rational temp that stores the product
rational operator * (const rational& op1, const rational& op2){
    rational temp;
    temp.numerator=op1.numerator*op2.numerator;
    temp.denominator=op1.denominator*op2.denominator;
    temp.simplify();
    return temp;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns a rational temp that stores the divident
rational operator / (const rational& op1, const rational& op2){
    rational temp;
    temp.numerator=op1.numerator*op2.denominator;
    temp.denominator=op1.denominator*op2.numerator;
    temp.simplify();
    return temp;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns a rational temp that stores the negative of the input
rational operator - (const rational& op1){
    rational temp;
    temp.numerator=-(op1.numerator);
    temp.denominator=op1.denominator;
    return temp;
}

//precondition: @param overloaded ostream and const rational 
//postcondition: output the fraction
ostream& operator <<(ostream& outs, const rational& op1){
    outs<<op1.numerator<<"/"<<op1.denominator;
}

//precondition: @param overloaded istream and const rational
//postcondition: returns the input
istream& operator >>(istream& ins, rational& op1){
    string s;
	bool isSlash = false, isNegative = false;
	bool isWhole = false;

	// Read a string (can read char by char, but less efficient).
	ins >> s;

	bool isValid = true;
	// Look at every character to see if it is valid
	for (int i = 0; i < s.length() && isValid; i++) 
	{
    	if (s[i] == '-')
		{ 
			// Must be at the beginning only
			isValid = ( i == 0) ? true : false;
			isNegative = (isValid) ? true : false;
		}
		else if (s[i] == '/')
		{
			// Must not be at the beginning or end or duplicated.
			isValid = (i == 0 || i == s.length()-1 || (i == 1 && isNegative ) || isSlash) ? false : true;
			isSlash = true;
		}
		else if (!isdigit(s[i])) {
			// Only valid characters are '-', '/'
			// and digits.
			isValid = false;
		}
	}

	// Set the failbit when not valid.
	if (isValid != true) {
		ins.setstate(ios::failbit);
		cerr << "Invalid rational format!" << endl;
		return ins;
	}

	// Smarter to use temporary variables because there can still be
	// an error with the denominator. We don't want to change the
	// rational if the read was unsucessful.
	int n, d;
	char c;
	istringstream iss;
	iss.str(s);
	if (isSlash) {
		iss >> n >> c >> d;
	}
	else {
		iss >> n;
		d = 1;
	}
	if (d == 0) {
		ins.setstate(ios::failbit);
		cerr << "Invalid rational format!" << endl;
		return ins;
	}
	op1.set(n, d);
	return ins;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns true if equals
bool operator ==(const rational& op1, const rational& op2){
    if((op1.numerator*op2.denominator)==(op2.numerator*op1.denominator))
        return true;
    return false;
    
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns true if not equals
bool operator !=(const rational& op1, const rational& op2){
    if((op1.numerator*op2.denominator)==(op2.numerator*op1.denominator))
        return false;
    return true;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns true if less than
bool operator <(const rational& op1, const rational& op2){
    if((op1.numerator*op2.denominator)<(op2.numerator*op1.denominator))
        return true;
    return false;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns true if less than or equal to
bool operator <=(const rational& op1, const rational& op2){
    if ((op1.numerator*op2.denominator)<=(op2.numerator*op1.denominator))
        return true;
    return false;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns true if greater than
bool operator >(const rational& op1, const rational& op2){
    if ((op1.numerator*op2.denominator)>(op2.numerator*op1.denominator))
        return true;
    return false;
}

//precondition: @param const rational&: unchangable inputs
//postcondition: returns true if greater than or equal to
bool operator >=(const rational& op1, const rational& op2){
    if ((op1.numerator*op2.denominator)>=(op2.numerator*op1.denominator))
        return true;
    return false;
}

//postcondition: simplifies the invoking object
void rational::simplify(){
    int a=numerator;
    int b=denominator;

   while (a!=0 && b!=0)
   {
      a = a % b;
      if (a!=0)
         b = b % a;
   }
        if (a==0)
        {
            numerator=numerator/b;
            denominator=denominator/b;
        }
            if (b==0)
            {
                numerator=numerator/a;
                denominator=denominator/a;
            }
}

//postcondition: returns counter from getCounter()
int rational::getObjectCounter(){
    return getCount();
}