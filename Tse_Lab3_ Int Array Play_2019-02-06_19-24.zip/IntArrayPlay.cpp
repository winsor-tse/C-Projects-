#include <iostream>

using namespace std;

const int CAPACITY=20;

// displayArray - display the array on a single line separated by blanks.
// @param: int array[] is an unordered array of integers
// @param: int numberOfElements
void displayArray(int array[], int numElements);

//ToDo: Declare a function fillArray that fills an int array with values entered
// by the user. Stop reading when the user inputs -1 or you reach CAPACITY.
// @param: int array[] is an unordered array of integers when leaving this function
// @param: int& numberElements is the number of Elements in the array after function
// @returns void.
void fillArray(int array[], int&numElements);

//ToDo: Declare a function that removes (i.e., deletes) the element
// removeElement - removes the element of the given index from the given array.
// @param: int array[] is an unordered array of integers
// @param: int numberElements
// @param: int position of element to delete
// @returns: true if delete was successful, false otherwise
bool removeElement(int array[], int &numberElements, int position);

//ToDo: Delcare a function that inserts the element in the given position
// insertElement - removes the element of the given index from the given array.
// @param: int array[] is an unordered array of integers
// @param: int numberElements
// @param: int position to insert into
// @param: int target to insert.
// @returns: true if insert was successful, false otherwise
bool insertElement(int array[], int&numberElements, int position, int target);

//ToDo: Declare a funcxtion that searches for an element in the given array
// searchElement - searches for the element in the given array.
// @param int array[] is an unordered array of integers
// @param int numberOfElements
// @param int target
// @returns index of element or -1 if not found.
int searchElement(int array[], int numberOfElements, int target);

int main()
{
  // The NumArray can be partially filled, we use variable NumArrayElems to keep track of how many numbers
  // have been stored in the array. 
  int NumArray[CAPACITY];	// an int array with a given CAPACITY
  int NumArrayElems=0;      // the array is initially empty, i.e., contains 0 elements

  // 1. ToDo: Call your fillArray function to read in a sequence of integer values,
  // separated by space, and ending with -1. Store the values in the NumArray array 
  // and the number of elements in NumArrayElems.
  // Display the contents of the array afterwards 
    fillArray(NumArray, NumArrayElems);
    displayArray(NumArray, NumArrayElems);
  // 2. ToDo: Read in a value and position from the user. Call your insertElement function
  // to insert the given value into the given position of the array 
  // Display the contents of the array afterwards
  int value, position;
    cout<<"Enter a value and a position to insert: ";
    cin>>value;
    cin>>position;
    insertElement(NumArray, NumArrayElems, position, value);
    displayArray(NumArray, NumArrayElems);
  // 3. ToDo: Read in a value and call your searchElement function.
  // if the value is  found, delete it from the array using your function
  // if the value not found, print "Value not found in array"
  // Display the contents of the array afterwards 
    cout<<"Enter a value to delete from the array: ";
    cin>>value;
    int index = searchElement(NumArray, NumArrayElems, value);
        if((removeElement(NumArray, NumArrayElems, index))==false)
            cout<<"Value not found!"<<endl;
            else
                displayArray(NumArray, NumArrayElems);
  // 5. TODO: Read in a value and call your insertElement function to append
  // a value to the end of the array 
  // Display the contents of the array afterwards 
    cout<<"Enter a value to append: ";
    cin>>value;
    insertElement(NumArray, NumArrayElems, NumArrayElems, value);
    displayArray(NumArray, NumArrayElems);
}

//TODO: Implement all functions declared above.
//Don't forget to put precondition/postcondition comments under or over the function header.

// displayArray - displays the array
// precondition: int array[] is an unordered array of numElems integers.
// postcondition: array is displayed on the console on a single line separated by blanks.
void displayArray(int array[], int numElems)
{
    for (int i = 0; i < numElems; i++)
        cout << array[i] << " ";
    cout << endl;
}

void fillArray(int array[], int&numElements){ 
    int input=0;
    cout<<"Enter a list of up to 20 integers or -1 to end the list"<<endl;
    do{
        cin>>input; //looks for input
        if(input!=-1){ //if the input is not -1
            array[numElements]=input; //the array is filled in the index of numElements
            numElements++;//adds 1 to numElements to keep count
        }
    }while((input!=-1)&&(numElements<CAPACITY));//loops until the user inputs -1 or the array is filled to CAPACITY
}

bool insertElement(int array[], int&numberElements, int position, int target){
    if((numberElements>position) && (position>=0)){
        int temp[numberElements]; //temp array that stores the values RIGHT of the position input
        for(int i=position; i<numberElements; i++){
            temp[i]=array[i]; //stores the values 
        }
        array[position]=target;//changes the value of the array[position]
        numberElements++;//adds 1 to numberElements because of right shift
            for(int i=position+1;i<numberElements; i++){ //starts with 1 index right of position
                array[i]=temp[i-1]; //array is filled with temp
            }
        return true;
    }
    else if(numberElements==position && numberElements<CAPACITY){ //case for appending an element
        numberElements++;
        array[position]=target;
        return true;
    }
    else
        return false;
}

int searchElement(int array[], int numberOfElements, int target){ //seraches if the target is in the array
    for(int i=0; i<numberOfElements; i++){
        if(array[i]==target)
            return i;
    }
    return -1;
}

bool removeElement(int array[], int &numberElements, int position){
    int temp[numberElements];//temp array that stores the values RIGHT of the position input
    if(position<=-1) //test case for false inputs
        return false;
        for(int i=position+1; i<numberElements; i++)
            temp[i]=array[i]; //storing values into temp
    numberElements--;//decrease numberElements because we are removing
            for(int i=position;i<numberElements; i++)
                array[i]=temp[i+1]; //replaces values with 1 index right of position
    return true;
    
}