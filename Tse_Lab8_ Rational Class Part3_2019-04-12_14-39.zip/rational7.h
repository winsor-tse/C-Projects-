/*  This rational class practice basics of defining and using class.
 */
#include <cctype>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <string>
#include <iostream>
#include <sstream>
#include <cstring>

using namespace std;

class rational
{
public:
   // TODO: set p and q to appropriate defaults
   rational (int p=0, int q=1){
       if(q==0){
        cout << "Error: Invalid parameters" << endl;
        exit(1);
       }
       numerator=p;
       denominator=q;
       getCount () ++;
   } // one constructor handles the work of 3.

   // TODO: Set invoking objec it's value from user input. Validate input is in
   //       the n/d form. 
   void input(istream& ins);

   // TODO: Display invoking object's value in the standard output, in the form
   //       of numerator/denominator 
   void output(ostream& outs);

   //TODO: add a set function that sets the numerator and denominator
    void set(const int &num, const int &dem);
   //TODO: implement the const function that returns the invoking object's numerator
   int get_numerator();

   //TODO: implement the const function that returns the invoking object's denominator
   int get_denominator();
    //overloaded + operator that returns the sum of op1 and op2
   friend rational operator +(const rational& op1, const rational& op2);
    //overloaded * operator that returns the product of op1 ad op2
    friend rational operator *(const rational& op1, const rational& op2);
   //overloaded / operator that returns the divident of op1 and op2
   friend rational operator /(const rational& op1, const rational& op2);
   //overloaded - operator that returns the difference of op1 and op2
   friend rational operator -(const rational& op1, const rational& op2);
   //overloaded - operator that returns the negative of op1
   friend rational operator -(const rational& op1);
   //overloaded == operator that returns true if satisfied
    friend bool operator ==(const rational& op1, const rational& op2);
   //overloaded != operator that returns true if satisfied
   friend bool operator !=(const rational& op1, const rational& op2);
   //overloaded < operator that returns true if satisfied
   friend bool operator <(const rational& op1, const rational& op2);
   //overloaded <= operator that returns true if satisfied
   friend bool operator <=(const rational& op1, const rational& op2);
   //overloaded > operator that returns true if satisfied
   friend bool operator >(const rational& op1, const rational& op2);
   //overloaded >= operator that returns true if satisfied
   friend bool operator >=(const rational& op1, const rational& op2);
   //overloaded >> operator that returns the istream 
   friend istream& operator >>(istream& ins, rational& op1);
   //overloaded << operator that prints out op1
   friend ostream& operator <<(ostream& outs, const rational& op1);
   
    int getObjectCounter();
    
    
private:
   int numerator;
   int denominator;
   //TODO: implement a function to simplify the product and sum.
    void simplify();
   //TODO: implement a static counter
    static int & getCount ()
    {
       static int theCount = 0;
       return theCount;
    }
};

/* Additional rational class Requirements
Merge the three constructors into one, by using default values for parameters (recall the example we have seen, Money class below.). 

*/