/* Implement Administrator class */
#include <iostream>
#include "Administrator.h"

using namespace std;

Administrator::Administrator():SalariedEmployee(), title("No title yet")
{
	// deliberately empty
}

// constructor with multiple arguements
Administrator::Administrator(string the_name, string the_number, double the_weekly_salary, string the_title) : SalariedEmployee(the_name, the_number, the_weekly_salary), title(the_title)

{
	// deliberately empty
 	// cout << "Adminstrator(" << name << "," << SSN << "," << salary << "," << title << ")\n"; 
}

// Mutator function to set the Adminstrator's title
void Administrator::set_title(string the_title)
{
    title = the_title;
}

// Accessor function for the title
string Administrator::get_title() const
{
    return title;
}

// ToDo: implement the print_check() function
void Administrator::print_check() 
{
	SalariedEmployee::print_check(); // Use SalariedEmployee print_check()
    cout << "Administrator Title: " << get_title() << endl;
}

